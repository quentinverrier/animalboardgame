export * from './main.config';
